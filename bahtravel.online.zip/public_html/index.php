<?php include 'header.php'; ?>


	
	<header id="gtco-header" class="gtco-cover gtco-cover-md" role="banner" style="background-image: url(images/img_bg_2.jpg)">
		<div class="overlay"></div>
		<div class="gtco-container">
			<div class="row">
				<div class="col-md-12 col-md-offset-0 text-left">
					

					<div class="row row-mt-15em">
						<div class="col-md-7 mt-text animate-box" data-animate-effect="fadeInUp">
							<h1>Planing Trip To Your Dream Destination?</h1>	
						</div>
						<div class="col-md-4 col-md-push-1 animate-box" data-animate-effect="fadeInRight">
							<div class="form-wrap">
								<div class="tab">
									
									<div class="tab-content">
										<div class="tab-content-inner active" data-content="signup">
											<h3>Book Your Trip Now</h3>
											<form action="https://forms.gle/aFwohEkjVB8G4C1DA">
												<div class="row form-group">
													

												<div class="row form-group">
													<div class="col-md-12">
														<input type="submit" class="btn btn-primary btn-block" value="Book Now">
													</div>
												</div>
											</form>	
										</div>

										
									</div>
								</div>
							</div>
						</div>
					</div>
							
					
				</div>
			</div>
		</div>
	</header>
	
	<div class="gtco-section">
		<div class="gtco-container">
			<div class="row">
				<div class="col-md-8 col-md-offset-2 text-center gtco-heading">
					<h2>Most Popular Destination</h2>
					<p>Our 3 most popular destinations are: Jeddah, Makkah and Madinah.</p>
				</div>
			</div>
			<div class="row">
				<!-- Makkah -->
				<div class="col-lg-4 col-md-4 col-sm-6" id="makkah">
					<div class="fh5co-card-item">
						<figure>
							<div class="overlay"><i class="ti-plus"></i></div>
							<img src="images/makkah.jpg" alt="Makkah - Holy City" class="img-responsive">
						</figure>
						<div class="fh5co-text">
							<h2>Makkah</h2>
							<p>Embark on a Spiritual Journey of a Lifetime</p>
							<p>
								<a href="https://forms.gle/aFwohEkjVB8G4C1DA" class="btn btn-primary" target="_blank">
									Schedule a Trip
								</a>
							</p>
						</div>
					</div>
				</div>
			
				<!-- Medina -->
				<div class="col-lg-4 col-md-4 col-sm-6" id="medina">
					<div class="fh5co-card-item">
						<figure>
							<div class="overlay"><i class="ti-plus"></i></div>
							<img src="images/medina.jpg" alt="Medina - The Prophet's City" class="img-responsive">
						</figure>
						<div class="fh5co-text">
							<h2>Medina</h2>
							<p>Plan Your Umrah with Ease & Peace of Mind</p>
							<p>
								<a href="https://forms.gle/aFwohEkjVB8G4C1DA" class="btn btn-primary" target="_blank">
									Schedule a Trip
								</a>
							</p>
						</div>
					</div>
				</div>
			
				<!-- Jeddah -->
				<div class="col-lg-4 col-md-4 col-sm-6" id="jeddah">
					<div class="fh5co-card-item">
						<figure>
							<div class="overlay"><i class="ti-plus"></i></div>
							<img src="images/jeddah.png" alt="Jeddah - The Gateway to Makkah" class="img-responsive">
						</figure>
						<div class="fh5co-text">
							<h2>Jeddah</h2>
							<p>Connecting Hearts to the Sacred Lands</p>
							<p>
								<a href="https://forms.gle/aFwohEkjVB8G4C1DA" class="btn btn-primary" target="_blank">
									Schedule a Trip
								</a>
							</p>
						</div>
					</div>
				</div>
			</div>
			
			
		</div>
	</div>
	
	<div id="gtco-features">
		<div class="gtco-container">
			<div class="row">
				<div class="col-md-8 col-md-offset-2 text-center gtco-heading animate-box">
					<h2>How It Works</h2>
					<p>Book Your Umrah Package Today in 3 Steps! Fill the form, pay a deposit and get a confirmation.</p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-4 col-sm-6">
					<div class="feature-center animate-box" data-animate-effect="fadeIn">
						<span class="icon">
							<i>1</i>
						</span>
						<h3>Pay full or half Deposit (50%)</h3>
						<p>Choose to pay for one of the three packages,<br>
						 <a href="https://revolut.me/umaru1uq9" target="_blank" style="color: black; font-weight: bold;">Click here...</a> to pay via Revolut.</p>
						<p>Alternatively, you can request to pay via Bank Transfer or PayPal</p>
				
		
					</div>
				</div>
				<div class="col-md-4 col-sm-6">
					<div class="feature-center animate-box" data-animate-effect="fadeIn">
						<span class="icon">
							<i>2</i>
						</span>
						<h3>Fill the form</h3>
						<p>Choose a flexible date so we can prepare your itenery accordingly. </p>
						<p> 
							Submit your details with a screenshot of your transaction 
							<a href="https://forms.gle/aFwohEkjVB8G4C1DA" target="_blank" style="color: black; font-weight: bold;"> to the form attached...</a>   </p>
					</div>
				</div>
				<div class="col-md-4 col-sm-6">
					<div class="feature-center animate-box" data-animate-effect="fadeIn">
						<span class="icon">
							<i>3</i>
						</span>
						<h3>Receive a confirmation</h3>
						<p>Upon receiving your confirmation, you can attend free online session to Plan, Prepare, and Perform with Ease				</p>
					</div>
				</div>
				

			</div>
		</div>
	</div>


	<div class="gtco-cover gtco-cover-sm" style="background-image: url(images/nabawi.jpg)"  data-stellar-background-ratio="0.5">
		<div class="overlay"></div>
		<div class="gtco-container text-center">
			<div class="display-t">
				<div class="display-tc">
					<h1>We strive to provide high quality services that you will surely love and appreciate!</h1>
				</div>	
			</div>
		</div>
	</div>

	<div id="gtco-counter" class="gtco-section">
		<div class="gtco-container">

			<div class="row">
				<div class="col-md-8 col-md-offset-2 text-center gtco-heading animate-box">
					<h2>Our Success</h2>
					<p>Our dedicated team is committed to making your pilgrimage stress-free and fulfilling.</p>
				</div>
			</div>

			<div class="row">
				
				<div class="col-md-3 col-sm-6 animate-box" data-animate-effect="fadeInUp">
					<div class="feature-center">
						<span class="counter js-counter" data-from="0" data-to="3" data-speed="10000" data-refresh-interval="50">1</span>
						<span class="counter-label">Destination</span>

					</div>
				</div>
				<div class="col-md-3 col-sm-6 animate-box" data-animate-effect="fadeInUp">
					<div class="feature-center">
						<span class="counter js-counter" data-from="0" data-to="17" data-speed="5000" data-refresh-interval="50">1</span>
						<span class="counter-label">Hotels</span>
					</div>
				</div>
					<div class="col-md-3 col-sm-6 animate-box" data-animate-effect="fadeInUp">
					<div class="feature-center">
						<span class="counter js-counter" data-from="0" data-to="12" data-speed="5000" data-refresh-interval="50">1</span>
						<span class="counter-label">Travelers</span>
					</div>
				</div>
				<div class="col-md-3 col-sm-6 animate-box" data-animate-effect="fadeInUp">
					<div class="feature-center">
						<span class="counter js-counter" data-from="0" data-to="10" data-speed="5000" data-refresh-interval="50">1</span>
						<span class="counter-label">Happy Customer</span>

					</div>
				</div>
					
			</div>
		</div>
	</div>

	

	<div id="gtco-subscribe">
		<div class="gtco-container">
			<div class="row animate-box">
				<div class="col-md-8 col-md-offset-2 text-center gtco-heading">
					<h2>Subscribe</h2>
					<p>Be the first to know about the new packages.</p>
				</div>
			</div>
			<div class="row animate-box">
				<div class="col-md-8 col-md-offset-2">
					<form class="form-inline" id="subscribe-form">
						<div class="col-md-6 col-sm-6">
							<div class="form-group">
								<label for="email" class="sr-only">Email</label>
								<input type="email" class="form-control" id="email" placeholder="Your Email">
							</div>
						</div>
						<div class="col-md-6 col-sm-6">
							<button type="submit" class="btn btn-default btn-block">Subscribe</button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
	
	<script>
	document.getElementById('subscribe-form').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent the form from submitting the traditional way

    // Get the email value from the input field
    const email = document.getElementById('email').value;

    // Validate the email (optional but recommended)
    if (!email || !email.includes('@')) {
        alert('Please enter a valid email address.');
        return;
    }

    // Send the email to the backend
    fetch('subscribe.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: 'email=' + encodeURIComponent(email),
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('Subscribed successfully with email: ' + email);
        } else {
            alert('Subscription failed: ' + data.message);
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('An error occurred. Please try again.');
    });
});
	</script>

	
<?php include 'footer.php'; ?>
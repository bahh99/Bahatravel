<?php include 'header.php'; ?>
	<header id="gtco-header" class="gtco-cover gtco-cover-sm" role="banner" style="background-image: url(images/medina.jpg)">
		<div class="overlay"></div>
		<div class="gtco-container">
			<div class="row">
				<div class="col-md-12 col-md-offset-0 text-center">
					<div class="row row-mt-15em">

						<div class="col-md-12 mt-text animate-box" data-animate-effect="fadeInUp">
							<h1>Plans for Everyone</h1>	
						</div>
						
					</div>
					
				</div>
			</div>
		</div>
	</header>
	
	<div class="gtco-section border-bottom">
		<div class="gtco-container">
			<div class="row">
				<div class="col-md-8 col-md-offset-2 text-center gtco-heading">
					<h2>Choose The Best Plan For You</h2>
					<p>We offer flexible packages from Individual trip, group trip and VIP Plus, according to your need </p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-4">
					<div class="price-box">
						<h2 class="pricing-plan">Individual</h2>
						<div class="price"><sup class="currency">€</sup>800 <sub class="sub">/ person</sub></div>
						<p>Basic support for Individual Pilgrim</p>
						<hr>
						<ul class="pricing-info">
							<li>Return Flight</li>
							<li>Tour Guide</li>
							<li>Visa</li>
						</ul>
						<a href="https://forms.gle/aFwohEkjVB8G4C1DA" class="btn btn-default btn-sm">Get started</a>
					</div>
				</div>
				<div class="col-md-4">
					<div class="price-box">
						<h2 class="pricing-plan">Group</h2>
						<div class="price"><sup class="currency">€</sup>650</div>
						<p>Standard support for group pilgrims</p>
						<hr>
						<ul class="pricing-info">
							<li>Return Flight</li>
							<li>Hotel</li>
							<li>Tour Guide</li>
							<li>Visa</li>
							
						</ul>
						<a href="https://forms.gle/aFwohEkjVB8G4C1DA" class="btn btn-default btn-sm">Get started</a>
					</div>
				</div>
				<div class="col-md-4">
					<div class="price-box popular">
						<div class="popular-text">VIP</div>
						<h2 class="pricing-plan">Plus</h2>
						<div class="price"><sup class="currency">€</sup>2000</div>
						<p>Exclusive support for Pilgrims</p>
						<hr>
						<ul class="pricing-info">
							<li>Return Flight</li>
							<li>Hotel</li>
							<li>Tour Guide</li>
							<li>Visa</li>
							<li>Transportation</li>
							<li>24/7 Online Support</li>
						</ul>
						<a href="https://forms.gle/aFwohEkjVB8G4C1DA" class="btn btn-primary btn-sm">Get started</a>
					</div>
				</div>
			</div>
		</div>
	</div>

	<div class="gtco-section">
		<div class="gtco-container">
			<div class="row">
				<div class="col-md-8 col-md-offset-2 text-center gtco-heading animate-box">
					<h2>Frequently Ask Questions</h2>
					<p>What is Umrah?
						Umrah is a pilgrimage to Mecca that can be performed at any time of the year, unlike Hajj, which has specific dates. It involves a set of rituals, including Tawaf (circumambulation of the Kaaba) and Sa’i (walking between Safa and Marwah).</p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-8 col-md-offset-2">
					<ul class="fh5co-faq-list">
						<li class="animate-box">
							<h2>What is Umrah?</h2>
							<p>To perform Umrah, you need a valid passport, an Umrah visa, proof of COVID-19 vaccination (if required by authorities), and a Mahram (for female travelers, as per Saudi regulations).</p>
						</li>
						<li class="animate-box">
							<h2>WWhat are the requirements for performing Umrah?</h2>
							<p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean.</p>
						</li>
						<li class="animate-box">
							<h2>Do you offer Umrah visa services?</h2>
							<p>Yes, we provide complete visa processing services to ensure a smooth and hassle-free experience for our pilgrims..</p>
						</li>
						<li class="animate-box">
							<h2>What is included in your Umrah packages?</h2>
							<p>Our Umrah packages typically include:</p>
							<ul>
								<li>Visa processing</li>
								<li>Flight bookings</li>
								<li>Accommodation near Haram</li>
								<li>Transportation within Saudi Arabia</li>
								<li>Guided tours (optional)</li>
							</ul>
						</li>
						<li class="animate-box">
							<h2>How can I book an Umrah package?</h2>
							<p>You can book an Umrah package through our website, by calling our customer service, or sending an email. Our team will guide you through the entire process.</p>
						</li>
						<li class="animate-box">
							<li class="animate-box">
								<h2>What should I pack for Umrah?</h2>
								<p>For Umrah, you should pack the following essentials:</p>
								<ul>
									<li>Ihram clothing (for men)</li>
									<li>Comfortable and modest clothing (for women)</li>
									<li>Comfortable walking shoes</li>
									<li>Personal hygiene items</li>
									<li>Travel documents (passport, visa, tickets)</li>
									<li>Prayer mat</li>
									<li>Small backpack for daily use</li>
									<li>Medications and first aid kit</li>
								</ul>
							</li>
						</li>
					</ul>
				</div>
			</div>
		</div>
	</div>

	
<div id="gtco-subscribe">
		<div class="gtco-container">
			<div class="row animate-box">
				<div class="col-md-8 col-md-offset-2 text-center gtco-heading">
					<h2>Subscribe</h2>
					<p>Be the first to know about our latest offers and new Umrah packages.</p>
				</div>
			</div>
			<div class="row animate-box">
				<div class="col-md-8 col-md-offset-2">
					<form class="form-inline" id="subscribe-form">
						<div class="col-md-6 col-sm-6">
							<div class="form-group">
								<label for="email" class="sr-only">Email</label>
								<input type="email" class="form-control" id="email" placeholder="Your Email">
							</div>
						</div>
						<div class="col-md-6 col-sm-6">
							<button type="submit" class="btn btn-default btn-block">Subscribe</button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
	
	<script>
	document.getElementById('subscribe-form').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent the form from submitting the traditional way

    // Get the email value from the input field
    const email = document.getElementById('email').value;

    // Validate the email (optional but recommended)
    if (!email || !email.includes('@')) {
        alert('Please enter a valid email address.');
        return;
    }

    // Send the email to the backend
    fetch('subscribe.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: 'email=' + encodeURIComponent(email),
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('Subscribed successfully with email: ' + email);
        } else {
            alert('Subscription failed: ' + data.message);
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('An error occurred. Please try again.');
    });
});
	</script>

	<?php include 'footer.php'; ?>
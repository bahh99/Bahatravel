<footer id="gtco-footer" role="contentinfo">
			<div class="gtco-container">
				<div class="row row-pb-md">
					<div class="col-md-4">
						<div class="gtco-widget">
							<h3>About Us</h3>
							<p>With years of experience, we provide seamless Umrah services to ensure a spiritually enriching journey.</p>
						</div>
					</div>
					<div class="col-md-2 col-md-push-1">
						<div class="gtco-widget">
							<h3>Destination</h3>
							<ul class="gtco-footer-links">
								<li><a href="#">Makkah</a></li>
								<li><a href="#">Medinah</a></li>
								<li><a href="#">Jeddah</a></li>
							</ul>
						</div>
					</div>
					<div class="col-md-2 col-md-push-1">
						<div class="gtco-widget">
							<h3>Hotels</h3>
							<ul class="gtco-footer-links">
								<li><a href="#">Albayt Ajyad Hotel</a></li>
								<li><a href="#">Shurakaa Al Khair Hotel</a></li>
								
							</ul>
						</div>
					</div>
					<div class="col-md-3 col-md-push-1">
						<div class="gtco-widget">
							<h3>Get In Touch</h3>
							<ul class="gtco-quick-contact">
								<li><a href="#"><i class="icon-phone"></i>+36204965463</a></li>
								<li><a href="mailto:info@bahtravel.online"><i class="icon-mail2"></i> info@bahtravel.online</a></li> 
								<li><a href="#"><i class="icon-chat"></i> Live Chat</a></li>
							</ul>
						</div>
					</div>
				</div>
				<div class="row copyright">
					<div class="col-md-12">
						<p class="pull-left">
							<small class="block">&copy; 2025 All Rights Reserved.</small> 
							<small class="block">Designed by Cyber Umar</small>
						</p>
						<p class="pull-right">
							<ul class="gtco-social-icons pull-right">
								<li><a href="#"><i class="icon-instagram"></i></a></li>
								<li><a href="https://www.facebook.com/profile.php?id=61573903420810"><i class="icon-facebook"></i></a></li>
								<li><a href="#"><i class="icon-linkedin"></i></a></li>
							</ul>
						</p>
					</div>
				</div>
			</div>
		</footer>
	</div>

	<div class="gototop js-top">
		<a href="#" class="js-gotop"><i class="icon-arrow-up"></i></a>
	</div>
	
	<!-- jQuery -->
	<script src="js/jquery.min.js"></script>
	<!-- jQuery Easing -->
	<script src="js/jquery.easing.1.3.js"></script>
	<!-- Bootstrap -->
	<script src="js/bootstrap.min.js"></script>
	<!-- Waypoints -->
	<script src="js/jquery.waypoints.min.js"></script>
	<!-- Carousel -->
	<script src="js/owl.carousel.min.js"></script>
	<!-- countTo -->
	<script src="js/jquery.countTo.js"></script>
	<!-- Stellar Parallax -->
	<script src="js/jquery.stellar.min.js"></script>
	<!-- Magnific Popup -->
	<script src="js/jquery.magnific-popup.min.js"></script>
	<script src="js/magnific-popup-options.js"></script>
	<!-- Datepicker -->
	<script src="js/bootstrap-datepicker.min.js"></script>
	<!-- Main -->
	<script src="js/main.js"></script>
</body>
</html>
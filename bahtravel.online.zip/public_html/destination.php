<?php include 'header.php'; ?>

	<header id="gtco-header" class="gtco-cover gtco-cover-sm" role="banner" style="background-image: url(images/makkah\ tower.jpg)">
		<div class="overlay"></div>
		<div class="gtco-container">
			<div class="row">
				<div class="col-md-12 col-md-offset-0 text-center">
					<div class="row row-mt-15em">

						<div class="col-md-12 mt-text animate-box" data-animate-effect="fadeInUp">
							<h1>Destination</h1>	
						</div>
						
					</div>
					
				</div>
			</div>
		</div>
	</header>
	
	<div class="gtco-section">
		<div class="gtco-container">
			<div class="row">
				<div class="col-md-8 col-md-offset-2 text-center gtco-heading">
					<h2>Most Popular Destination</h2>
					<p>Our 3 most popular destinations are: Jeddah, Makkah and Madinah.</p>
				</div>
			</div>
			<div class="row">
				<!-- Makkah -->
				<div class="col-lg-4 col-md-4 col-sm-6" id="makkah">
					<div class="fh5co-card-item">
						<figure>
							<div class="overlay"><i class="ti-plus"></i></div>
							<img src="images/makkah99.jpg" alt="Makkah - Holy City" class="img-responsive">
						</figure>
						<div class="fh5co-text">
							<h2>Makkah</h2>
							<p>Embark on a Spiritual Journey of a Lifetime</p>
							<p>
								<a href="https://forms.gle/aFwohEkjVB8G4C1DA" class="btn btn-primary" target="_blank">
									Schedule a Trip
								</a>
							</p>
						</div>
					</div>
				</div>
			
				<!-- Medina -->
				<div class="col-lg-4 col-md-4 col-sm-6" id="medina">
					<div class="fh5co-card-item">
						<figure>
							<div class="overlay"><i class="ti-plus"></i></div>
							<img src="images/medina.jpg" alt="Medina - The Prophet's City" class="img-responsive">
						</figure>
						<div class="fh5co-text">
							<h2>Medina</h2>
							<p>Plan Your Umrah with Ease & Peace of Mind</p>
							<p>
								<a href="https://forms.gle/aFwohEkjVB8G4C1DA" class="btn btn-primary" target="_blank">
									Schedule a Trip
								</a>
							</p>
						</div>
					</div>
				</div>
			
				<!-- Jeddah -->
				<div class="col-lg-4 col-md-4 col-sm-6" id="jeddah">
					<div class="fh5co-card-item">
						<figure>
							<div class="overlay"><i class="ti-plus"></i></div>
							<img src="images/jeddah.png" alt="Jeddah - The Gateway to Makkah" class="img-responsive">
						</figure>
						<div class="fh5co-text">
							<h2>Jeddah</h2>
							<p>Connecting Hearts to the Sacred Lands</p>
							<p>
								<a href="https://forms.gle/aFwohEkjVB8G4C1DA" class="btn btn-primary" target="_blank">
									Schedule a Trip
								</a>
							</p>
						</div>
					</div>
				</div>
			</div>
			
			
		</div>>
	</div>
	

	
	<div id="gtco-subscribe">
		<div class="gtco-container">
			<div class="row animate-box">
				<div class="col-md-8 col-md-offset-2 text-center gtco-heading">
					<h2>Subscribe</h2>
					<p>Be the first to know about our latest offers and new Umrah packages.</p>
				</div>
			</div>
			<div class="row animate-box">
				<div class="col-md-8 col-md-offset-2">
					<form class="form-inline" id="subscribe-form">
						<div class="col-md-6 col-sm-6">
							<div class="form-group">
								<label for="email" class="sr-only">Email</label>
								<input type="email" class="form-control" id="email" placeholder="Your Email">
							</div>
						</div>
						<div class="col-md-6 col-sm-6">
							<button type="submit" class="btn btn-default btn-block">Subscribe</button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
	
	<script>
	document.getElementById('subscribe-form').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent the form from submitting the traditional way

    // Get the email value from the input field
    const email = document.getElementById('email').value;

    // Validate the email (optional but recommended)
    if (!email || !email.includes('@')) {
        alert('Please enter a valid email address.');
        return;
    }

    // Send the email to the backend
    fetch('subscribe.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: 'email=' + encodeURIComponent(email),
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('Subscribed successfully with email: ' + email);
        } else {
            alert('Subscription failed: ' + data.message);
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('An error occurred. Please try again.');
    });
});
	</script>

	<?php include 'footer.php'; ?>
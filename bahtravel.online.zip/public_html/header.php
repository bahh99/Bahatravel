<!DOCTYPE HTML>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Umrah &mdash; sacred visit</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="Book your Umrah and Hajj journey with BahTravel for a stress-free, spiritually fulfilling experience. We offer all-inclusive travel packages from Budapest and cities across Europe, tailored to your needs." />
	<meta name="keywords" content="umrah, hajj, pilgrimage, travel, islam, muslim, makkah, medinah, saudi arabia, package, journey, spiritual, religious, all-inclusive, europe, budapest, hungary, visa, flight, accommodation, transportation, guided tours, prayer, ihram, clothing, shoes, hygiene, documents, passport, tickets, mat, backpack, medications, first aid, kit, customer service, email, phone, live chat, social media, twitter, facebook, linkedin, dribbble, subscribe, success, destination, hotels, travelers, happy, customer, contact, pricing, about, services, team, stress-free, fulfilling, high quality, appreciate, new, templates, packages, subscribe, news, updates, journey, experience, spiritually, fulfilling, stress-free, all-inclusive, travel, packages, budapest, cities, europe, tailored, needs, umrah, hajj, pilgrimage, travel, islam, muslim, makkah, medinah, saudi arabia, package, journey, spiritual, religious, all-inclusive, europe, budapest, hungary, visa, flight, accommodation, transportation, guided tours, prayer, ihram, clothing, shoes, hygiene, documents, passport, tickets, mat, backpack, medications, first aid, kit, customer service, email, phone, live chat, social media, twitter, facebook, linkedin, dribbble, subscribe, success, destination, hotels, travelers, happy, customer, contact, pricing, about, services, team, stress-free, fulfilling, high quality, appreciate, new, templates, packages, subscribe, news, updates, journey, experience, spiritually, fulfilling, stress-free, all-inclusive, travel, packages, budapest, cities, europe, tailored, needs, umrah, hajj, pilgrimage, travel, islam, muslim, makkah, medinah, saudi arabia, package, journey, spiritual, religious, all-inclusive, europe, budapest, hungary, visa, flight, accommodation, transportation, guided tours, prayer, ihram, clothing, shoes, hygiene, documents, passport, tickets, mat, backpack, medications, first aid, kit, customer service, email, phone, live chat, social media, twitter, facebook, linkedin, dribbble, subscribe, success, destination">
	<meta name="author" content="Cyber Umar">
	<meta name="robots" content="index, follow">
	<meta name="revisit-after" content="1 month">
	<meta name="language" content="English">
	<meta name="distribution" content="global">
	<meta name="rating" content="safe for kids">
	<meta name="googlebot" content="noodp">
	<meta name="google" content="nositelinkssearchbox">
	<meta name="google" content="notranslate">
	<meta name="google" content="noimageindex">
	<meta name="google" content="noarchive">
	<meta name="google" content="nosnippet">
	<meta name="google" content="max-snippet:-1">
	<meta name="google" content="max-image-preview:large">
	<meta name="google" content="max-video-preview:-1">
	<meta name="google" content="notranslate">
	<meta name="google" content="noindex">
	<meta name="google" content="noarchive">

<!-- Favicon -->
<link rel="icon" href="https://bahtravel.online/favicon.ico" type="image/x-icon">


	<!-- Facebook and Twitter integration -->
	<meta property="og:title" content=""/>
	<meta property="og:image" content=""/>
	<meta property="og:url" content=""/>
	<meta property="og:site_name" content=""/>
	<meta property="og:description" content=""/>
	<meta name="twitter:title" content="" />
	<meta name="twitter:image" content="" />
	<meta name="twitter:url" content="" />
	<meta name="twitter:card" content="" />

	<link href="https://fonts.googleapis.com/css?family=Lato:300,400,700" rel="stylesheet">
	
	<!-- Animate.css -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="css/icomoon.css">
	<!-- Themify Icons-->
	<link rel="stylesheet" href="css/themify-icons.css">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="css/bootstrap.css">
	<!-- Magnific Popup -->
	<link rel="stylesheet" href="css/magnific-popup.css">
	<!-- Magnific Popup -->
	<link rel="stylesheet" href="css/bootstrap-datepicker.min.css">
	<!-- Owl Carousel  -->
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">
	<!-- Theme style  -->
	<link rel="stylesheet" href="css/style.css">
	<!-- Modernizr JS -->
	<script src="js/modernizr-2.6.2.min.js"></script>
	<!-- FOR IE9 below -->
	<!--[if lt IE 9]>
	<script src="js/respond.min.js"></script>
	<![endif]-->
</head>
<body>
	<div class="gtco-loader"></div>
	<div id="page">
		<nav class="gtco-nav" role="navigation">
			<div class="gtco-container">
				<div class="row">
					<div class="col-sm-4 col-xs-12">
						<div id="gtco-logo"><a href="index.php">Umrah Trip <em>.</em></a></div>
					</div>
					<div class="col-xs-8 text-right menu-1">
						<ul>
							<li><a href="destination.php">Destination</a></li>
								<li><a href="overview.php">Trip Overview</a></li>
							<li class="has-dropdown">
								<a href="#">Travel</a>
								<ul class="dropdown">
									<li><a href="overview.php">Makkah</a></li> 
									<li><a href="#medinah">Medinah</a></li>
								</ul>
							</li>
							<li><a href="pricing.php">Pricing</a></li>
							<li><a href="contact.php">Contact</a></li>
						</ul>	
					</div>
				</div>
			</div>
		</nav>
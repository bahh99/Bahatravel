<?php
// Database configuration
$host = 'localhost'; // Database host
$dbname = 'u333239021_umrah'; // Database name
$username = 'u333239021_bahtravel'; // Database username
$password = 'BahTravel@572592'; // Database password

// Connect to the database
try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Handle the subscription form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];

    // Validate the email
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode(['success' => false, 'message' => 'Invalid email address.']);
        exit;
    }

    // Insert the email into the database
    try {
        $stmt = $conn->prepare('INSERT INTO subscribers (email) VALUES (:email)');
        $stmt->execute(['email' => $email]);
        echo json_encode(['success' => true, 'message' => 'Subscription successful!']);
    } catch (PDOException $e) {
        if ($e->getCode() == 23000) { // Duplicate entry error
            echo json_encode(['success' => false, 'message' => 'Email already subscribed.']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Database error.']);
        }
    }
}
?>
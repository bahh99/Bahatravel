<?php include 'header.php'; ?>


	
	<header id="gtco-header" class="gtco-cover gtco-cover-md" role="banner" style="background-image: url(images/makkah99.jpg)">
		<div class="overlay"></div>
		<div class="gtco-container">
			<div class="row">
				<div class="col-md-12 col-md-offset-0 text-left">
					

					<div class="row row-mt-15em">
						<div class="col-md-7 mt-text animate-box" data-animate-effect="fadeInUp">
							<h1>Planing Trip To Your Dream Destination?</h1>	
						</div>
						<div class="col-md-4 col-md-push-1 animate-box" data-animate-effect="fadeInRight">
							
						</div>
					</div>
							
					
				</div>
			</div>
		</div>
	</header>
	
    <div class="gtco-section">
        <div class="gtco-container">
            <div class="row">
                <div class="col-md-8 col-md-offset-2 text-center gtco-heading">
                    <h2>Trip Overview</h2>
                    <p>After arrival to the Jeddah Airport:</p>
                </div>
            </div>
            <div class="row">
                <!-- Step 1 -->
                <div class="col-lg-3 col-md-3 col-sm-6">
                    <div class="fh5co-card-item">
                        <div class="fh5co-text">
                            <h2>Step 1</h2>
                            <p>From Jeddah airport, We go the hotel in Makkah directly, we refresh and take some energy.</p>
                        </div>
                    </div>
                </div>
                <!-- Step 2 -->
                <div class="col-lg-3 col-md-3 col-sm-6">
                    <div class="fh5co-card-item">
                        <div class="fh5co-text">
                            <h2>Step 2</h2>
                            <p>After an hour or two, we go to the Haram to perform Umrah on the same day.</p>
                        </div>
                    </div>
                </div>
                <!-- Step 3 -->
                <div class="col-lg-3 col-md-3 col-sm-6">
                    <div class="fh5co-card-item">
                        <div class="fh5co-text">
                            <h2>Step 3</h2>
                            <p>After few days, we will go Masjid Al Nabawi in Medinah by bus. explore the road on a 4 hour journey</p>
                        </div>
                    </div>
                </div>
                <!-- Step 4 -->
                <div class="col-lg-3 col-md-3 col-sm-6">
                    <div class="fh5co-card-item">
                        <div class="fh5co-text">
                            <h2>Step 4</h2>
                            <p>On the last day, we will return to the Jeddah airport by the HHR train. High speed trains from Medinah</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
	<!-- hotel -->
    <div class="gtco-section">
        <div class="gtco-container">
            <div class="row">
                <div class="col-md-8 col-md-offset-2 text-center gtco-heading">
                    <h2>Top Hotels</h2>
                    <p>Our recommended hotels for your stay.</p>
                </div>
            </div>
            <div class="row">
                <!-- Hotel 1 -->
                <div class="col-lg-4 col-md-4 col-sm-6">
                    <div class="fh5co-card-item">
                        <figure>
                            <div class="overlay"><i class="ti-plus"></i></div>
                            <img src="images/hotel1.jpg" alt="Hotel 1" class="img-responsive">
                        </figure>
                        <div class="fh5co-text">
                            <h2>Ajyad Albait Hotel </h2>
                            <p>Experience luxury and comfort.</p>
                        </div>
                    </div>
                </div>
            
                <!-- Hotel 2 -->
                <div class="col-lg-4 col-md-4 col-sm-6">
                    <div class="fh5co-card-item">
                        <figure>
                            <div class="overlay"><i class="ti-plus"></i></div>
                            <img src="images/hotel2.jpg" alt="Hotel 2" class="img-responsive">
                        </figure>
                        <div class="fh5co-text">
                            <h2>Ajyad Albait Hotel </h2>
                            <p>Enjoy a relaxing stay with us.</p>
                        </div>
                    </div>
                </div>
            
                <!-- Hotel 3 -->
                <div class="col-lg-4 col-md-4 col-sm-6">
                    <div class="fh5co-card-item">
                        <figure>
                            <div class="overlay"><i class="ti-plus"></i></div>
                            <img src="images/hotel3.jpg" alt="Hotel 3" class="img-responsive">
                        </figure>
                        <div class="fh5co-text">
                            <h2>Ajyad Albait Hotel 3</h2>
                            <p>Comfort and convenience at its best.</p>
                        </div>
                    </div>
                </div>

                <!-- Hotel 4-->

                <div class="col-lg-4 col-md-4 col-sm-6">
                    <div class="fh5co-card-item">
                        <figure>
                            <div class="overlay"><i class="ti-plus"></i></div>
                            <img src="images/hotel4.jpg" alt="Hotel 1" class="img-responsive">
                        </figure>
                        <div class="fh5co-text">
                            <h2>Shurakaa Al Khair Hotel </h2>
                            <p>Experience luxury and comfort.</p>
                        </div>
                    </div>
                </div>
            
                <!-- Hotel 5 -->
                <div class="col-lg-4 col-md-4 col-sm-6">
                    <div class="fh5co-card-item">
                        <figure>
                            <div class="overlay"><i class="ti-plus"></i></div>
                            <img src="images/hotel5.jpg" alt="Hotel 2" class="img-responsive">
                        </figure>
                        <div class="fh5co-text">
                            <h2>Shurakaa Al Khair Hotel </h2>
                            <p>Enjoy a relaxing stay with us.</p>
                        </div>
                    </div>
                </div>
            
                <!-- Hotel 6 -->
                <div class="col-lg-4 col-md-4 col-sm-6">
                    <div class="fh5co-card-item">
                        <figure>
                            <div class="overlay"><i class="ti-plus"></i></div>
                            <img src="images/hotel6.jpg" alt="Hotel 3" class="img-responsive">
                        </figure>
                        <div class="fh5co-text">
                            <h2>Shurakaa Al Khair Hotel</h2>
                            <p>Comfort and convenience at its best.</p>
                        </div>
                    </div>
                </div>

               
            </div>
        </div>
    </div>
	

	<div id="gtco-subscribe">
		<div class="gtco-container">
			<div class="row animate-box">
				<div class="col-md-8 col-md-offset-2 text-center gtco-heading">
					<h2>Subscribe</h2>
					<p>Be the first to know about our latest offers and new Umrah packages.</p>
				</div>
			</div>
			<div class="row animate-box">
				<div class="col-md-8 col-md-offset-2">
					<form class="form-inline" id="subscribe-form">
						<div class="col-md-6 col-sm-6">
							<div class="form-group">
								<label for="email" class="sr-only">Email</label>
								<input type="email" class="form-control" id="email" placeholder="Your Email">
							</div>
						</div>
						<div class="col-md-6 col-sm-6">
							<button type="submit" class="btn btn-default btn-block">Subscribe</button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
	
	<script>
	document.getElementById('subscribe-form').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent the form from submitting the traditional way

    // Get the email value from the input field
    const email = document.getElementById('email').value;

    // Validate the email (optional but recommended)
    if (!email || !email.includes('@')) {
        alert('Please enter a valid email address.');
        return;
    }

    // Send the email to the backend
    fetch('subscribe.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: 'email=' + encodeURIComponent(email),
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('Subscribed successfully with email: ' + email);
        } else {
            alert('Subscription failed: ' + data.message);
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('An error occurred. Please try again.');
    });
});
	</script>

	
<?php include 'footer.php'; ?>